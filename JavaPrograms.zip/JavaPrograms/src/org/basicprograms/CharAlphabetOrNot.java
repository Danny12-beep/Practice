package org.basicprograms;

import java.util.Scanner;

public class CharAlphabetOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char ch;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Character");
		ch = sc.next().charAt(0);
		
			if((ch>='a' && ch <= 'z') || (ch>='A' && ch <='Z') ) {
				System.out.println(ch + " is Alphabet");
			} else {
				System.out.println(ch + " is Not Alphabet");
		}
	}
}
