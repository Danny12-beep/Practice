package org.basicprograms;

import java.util.Scanner;

public class SumOfNaturalNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int num=50, sum=0;
		for(int i=1; i<=num; i++) {
			sum = sum + i;
		}
		System.out.println("Sum: "+sum);
	}
}
