package org.basicprograms;

public class IntegersDivisibleBy3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		for(int i = 3; i <= 127; i++) {
			if(i%3==0) {
				System.out.println(i + " Number is divisible");
			}
		}
	}
}
