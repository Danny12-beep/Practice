package org.basicprograms;

import java.util.Scanner;

public class NumberPositiveOrNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number");
		int n = sc.nextInt();
		if(n > 0) {
			System.out.println("Number Is Positive");
		} else {
			System.out.println("Number Is Negative");
		}
	}

}
