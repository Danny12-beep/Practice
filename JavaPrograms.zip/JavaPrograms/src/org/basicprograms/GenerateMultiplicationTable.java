package org.basicprograms;

import java.util.Scanner;

public class GenerateMultiplicationTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int n, m;
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Number");
			n = sc.nextInt();
			
			for(int i=1;i<=10;i++) {	
				m = n * i;
				System.out.println(n+" = "+n+" x "+i+" = "+m);
			}
			
	}
}
