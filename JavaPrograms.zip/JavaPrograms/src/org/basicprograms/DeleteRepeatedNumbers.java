package org.basicprograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class DeleteRepeatedNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] lst = {1,1,1,2,3,3,3,8,1,4,5,5,9,0,2,3};
		System.out.println(Arrays.asList(lst));
		HashSet h=new HashSet();
		for(int i:lst)
		{
			h.add(i);
		}
		System.out.println(h);
	}
}
